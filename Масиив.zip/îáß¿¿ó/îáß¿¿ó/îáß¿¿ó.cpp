﻿#include <iostream>
#include <vector>
#include <set>
using namespace std;

int main()
{
	const int n = 4;
	int numbers[n];
	for (int i = 0; i < 4; i++)
	{
		cin >> numbers[i];
	}
	int target;
	cout << "\nEnter target:\n";
	cin >> target;
	cout << "Enter count of array:\n";
	int count;
	cin >> count;
	set<int>arraynumbers;
	int i=0;
	while(i<count)
	{
		i++;
		int m = rand() % 4;
		arraynumbers.insert(numbers[m]);
	}
    for (int n : numbers) 
    {
        cout << n << "\t";
    }
    cout << "\n";
    int con = 4;
    vector<set<int>::iterator> it;
    for (int i = 0; i < con; ++i) {
        it.push_back(arraynumbers.begin());
    }

    for (auto itit = it.begin(); itit != it.end();) {
        for (; *itit != arraynumbers.end(); ++(*itit)) {
            int sum = 0;
            for (auto itits = it.begin(); itits != it.end(); ++itits) {
                sum += **itits;
            }
            if (sum == target) {
                auto itits = it.begin();
                cout << sum << " = " << **itits;
                ++itits;
                for (; itits != it.end(); ++itits) {
                    cout << " + " << **itits;
                }
                cout << "\n";
            }
        }
        for (; itit != it.end(); ++itit) {
            if (*itit == arraynumbers.end()) {
                ;
                *itit = arraynumbers.begin();
            }
            else {
                ++(*itit);
                if (*itit != arraynumbers.end()) {
                    itit = it.begin();
                }
                break;
            }
        }
    }
}