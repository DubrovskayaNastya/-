﻿#include <iostream>
#include <list>

using namespace std;

int main()
{
	srand(static_cast<unsigned>(time(NULL)));
	list<int>numbers;
	int n = 0;
	for (auto i = 0; i < 10; i++)
	{
		n = rand() % 6;
		numbers.push_back(n);
	}
	cout << "Numbers:\n";
	for (auto itr = numbers.begin(); itr != numbers.end(); itr++)
	{
		cout << *itr << "\t";
	}
	for (auto itr = numbers.begin(); itr != numbers.end(); itr++)
	{
		if (*itr == 3)
		{
			if (itr == numbers.begin())
			{
				numbers.pop_back();
			}
			else
			{
				itr--;
				numbers.erase(itr--);
				itr++;
			}
		}
	}
	cout << "\nNew numbers:\n";
	for (auto itr = numbers.begin(); itr != numbers.end(); itr++)
	{
		cout << *itr << "\t";
	}
	return 0;
}