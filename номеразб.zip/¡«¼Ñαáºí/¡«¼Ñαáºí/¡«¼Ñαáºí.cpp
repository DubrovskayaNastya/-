﻿#include <iostream>
#include <vector>
#include <fstream>
#include <string>
using namespace std;

string numbers()
{
	string number="+375";
	int num;
	for (int i = 0; i < 3; i++)
	{
		num = rand() % (57 - 48 + 1)+48;
		number += char(num);
	}
	number = number + "-";
	for (int i = 0; i < 2; i++)
	{	
		num = rand() % (57 - 48 + 1)+48;
		number += char(num);
	}
	number = number + "-";
	for (int i = 0; i < 2; i++)
	{
		num = rand() % (57 - 48 + 1)+48;
		number += char(num);

	}
	return number;
}

int main()
{
	srand(static_cast<unsigned>(time(NULL)));
	ofstream fileToText;
	fileToText.open("Name.txt", ios::app);
	ifstream file;
	file.open("Name.txt", ios::app);
	string name;
	cout << "Enter your name and surname:\n";
	getline(cin, name);
	string passportSeries;
	cout << "Enter your passport series:\n";
	getline(cin, passportSeries);
	bool TryFalse=false;
	do{
		int count = 0;
		if (passportSeries.size() == 9)
		{
			if (passportSeries[0] >= '65' || passportSeries[0] <= '90' || passportSeries[1] >= '65' || passportSeries[1] <= '90')
			{
				for (int i = 2; i <=9; i++)
				{
					if (passportSeries[i] >= '48' || passportSeries[i] <= '57')
					{
					}
					else
					{
						count++;
					}
				}
				if (count > 0)
				{
					cout << "Error! (You made a some mistake )\n";
					passportSeries = " ";
					getline(cin, passportSeries);
				}
				if (count == 0)
				{
					TryFalse = true;
				}
			}
			else 
			{
				cout << "Error! (You made a some mistake)\n";
				passportSeries = " ";
				getline(cin, passportSeries);
			}
		}
		else 
		{
			cout << "Error!( leght passport series is 9 elements)!\n";
			passportSeries = " ";
			getline(cin, passportSeries);
		}
		
	} while (TryFalse == false);
	string someWord;
	int countOfWords=0;
	while (file >> someWord)
	{
		if (someWord == passportSeries)
		{
			countOfWords++;
			cout << "You have a number on this account!\n";
			return 0;
		}
	}
	if (countOfWords == 0)
	{
		fileToText << name << "\t" << passportSeries << "\t";
	}
	int choice;
	cout << "Choose a tariff: 1) A1; 2) MTC; 3) Life;\n";
	cin >> choice;
	string newnumbers;
		switch (choice)
		{
			case 1:
				newnumbers = numbers();
				newnumbers.insert(4, "(");
				if (newnumbers[5] == '49' || newnumbers[5] == '51' || newnumbers[5] == '54' || newnumbers[5] == '57')
				{
					newnumbers.insert(5 ,"29");
				}
				else
				{
					newnumbers.insert(5, "44");
				}
				newnumbers.insert( 7, ")");
				break;
			case 2:
				newnumbers = numbers();
				newnumbers.insert( 4, "(");
				if (newnumbers[5] == '50' || newnumbers[5] == '53' || newnumbers[5] == '55' || newnumbers[5] == '56')
				{
					newnumbers.insert( 5, "29");
				}
				else
				{
					newnumbers.insert( 5, "33");
				}
				newnumbers.insert( 7, ")");
				break;
			case 3:
				newnumbers = numbers();
				newnumbers.insert( 4, "(");
				newnumbers.insert( 5, "25");
				newnumbers.insert( 7, ")");
				break;
			default:
				break;
		}
		string someWordsForNumbers;
		int countOfWordsForNumbers = 0;
		while (file >> someWordsForNumbers)
		{
			
			if (someWordsForNumbers == newnumbers)
			{
				countOfWordsForNumbers++;
				cout << "This number have.Try again!\n";
				return 0;
			}
		}
		if (countOfWordsForNumbers == 0)
		{
			for (int i = 0; i < newnumbers.size(); i++)
			{
				fileToText << newnumbers[i];
			}
			fileToText << "\n";
		}
		for (int i = 0; i < newnumbers.size(); i++)
		{
			cout << newnumbers[i];

		}
	file.close();
	fileToText.close();
	return 0;
}