﻿#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main()
{
	vector<string>nomera;
	cout << "Enter some thing:\n";
	string newnomera;
	while (getline(cin,newnomera))
	{
		nomera.push_back(newnomera);
	}
	for (int i = 0; i < nomera.size(); i++)
	{
		if (nomera[i].size() != 6)
		{
			cout << nomera[i] << "\t" << "No!\n";
			nomera.erase(nomera.begin() + i);
		}
	}
	for (int i = 0; i < nomera.size(); i++)
	{
		if (isdigit(nomera[i][0])||(nomera[i][0]<'65'||nomera[i][0]>'90'))
		{
			cout << nomera[i] << "\t" << "No!\n";
			nomera.erase(nomera.begin()+i);
		}
		if ((nomera[i][1]<'0'||nomera[i][1]>'9') || (nomera[i][2] < '0' || nomera[i][2]>'9') || (nomera[i][3] < '0' || nomera[i][3]>'9'))
		{
			cout << nomera[i] << "\t" << "No!\n";
			nomera.erase(nomera.begin() + i);
		}
		if (isdigit(nomera[i][4]) || (nomera[i][4] < '65' || nomera[i][4]>'90'))
		{
			cout << nomera[i] << "\t" << "No!\n";
			nomera.erase(nomera.begin() + i);
		}
		if (isdigit(nomera[i][5]) || (nomera[i][5] < '65' || nomera[i][5]>'90'))
		{
			cout << nomera[i] << "\t" << "No!\n";
			nomera.erase(nomera.begin() + i);
		}
	}
	for (int i = 0; i < nomera.size(); i++)
	{
		cout << nomera[i] << "\t Yes!\n";
	}
}