﻿#include <iostream>
#include <conio.h>
#include <Windows.h>
#include <string>
#include <vector>

using namespace std;

vector<char> c1;
char c;
void Fun()
{
	while (!GetAsyncKeyState(VK_RETURN))
	{
		c = _getch();
		c1.push_back(c);
			if (isdigit(c))
			{
				cout << c;
			}
			else {
				system("exit");
			}
		if (GetAsyncKeyState(VK_BACK))
		{
			cout << '\b' << ' ' << '\b';
			c1.pop_back();
			c = _getch();
			c1.push_back(c);
			if (isdigit(c))
			{
				cout << c;
			}
			else {
				system("exit");
			}
		}
	}
}
int main()
{
	Fun();
	return 0;
}
