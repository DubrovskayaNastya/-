﻿#include <iostream>
#include <fstream>
#include <string> 
#include <math.h>
using namespace std;

int main()
{
    setlocale(LC_ALL, "");
    cout << "Тест по Dota2\n\n"; 
	string s;
    string answer;
	ifstream fil("Dota2.txt");
    int right=0;
    int count=0;
    while (getline(fil, s)) { 
        ++count;
        if (count % 2 == 0)
        {
            getline(cin, answer);
            if (answer == s)
            {
                right++;
            }
        }
        else
        {
          cout << s << "\n";
        }
    }
    double result = right / (count / static_cast<double>(2)) * 100;
    if (result == 100)
    {
        cout << "Отлично!";
    }
    if (result>=80&&result<100)
    {
        cout << "Хорошо";
    }
    if (result>=60&&result<80)
    {
        cout << "Нормально";
    }
    if (result>=0&&result<60)
    {
        cout << "Удовлетворительно";
    }
    fil.close();
    return 0;
}