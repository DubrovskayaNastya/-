﻿#include <iostream>
#include <string>
#include <cmath>
#include <vector>
using namespace std;

int main()
{
	int numbers;
	cout << "Enter numbers:\n";
	cin >> numbers;
	if (numbers <= 1 || numbers > (pow(2, 26)))
	{
		return 0;
	}
	vector<char>letter;
	int count = 0;
	for (char i = 97; i < 123; i++)
	{
		count++;
		if (count >= 2) {
			letter.insert(letter.begin(), 97);
			for (int n = 0; n < count; n++)
			{
				letter.insert(letter.begin(), 97 + n);
			}
		}
	}
	for (int i = 0; i < letter.size(); i++)
	{
		cout << letter[i];
	}
	cout << "\n";
	for (int i = 0; i < letter.size(); i++)
	{
		if (i == numbers)
		{
			cout << letter[i-1];
		}
	}
	return 0;
}