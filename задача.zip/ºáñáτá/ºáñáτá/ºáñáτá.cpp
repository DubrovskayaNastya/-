﻿#include <iostream>
#include <string>
#include <Windows.h>
#include <stack>
#include <math.h>

using namespace std;
int fundnumbers(string text)
{
	stack<int>objects;
	int number;
	for (int i = 0; i < text.size(); i++)
	{
		if (isdigit(text[i]))
	{
		string texts;
		while (i < text.size() && (isdigit(text[i]))) {
			texts += text[i];
				i++;
		}
			i--;
		objects.push(stod(text));
		number = objects.top();
		objects.pop();
	}
	}
	return number;
}

int main()
{
	setlocale(0, " ");
	SetConsoleCP(CP_UTF8);
	SetConsoleOutputCP(CP_UTF8);
	string first;
	string second;
	string exam = ",";
	cout << "Enter first text:\n";
	getline(cin, first);
	cout << "\nEnter second text:\n";
	getline(cin, second);
	int count = 0;
	if (first.size() >= 1000||second.size()>=1000)//проверка на размер наших текстов
	{
		return 0;
	}
	for (int i = 0; i < first.size(); i++)//через цикл считаем колличество запятых в первой строке
	{
		if (first[i] == exam[0])
		{
			count++;
		}
	}
	if (count == 3)
	{
		count = 0;
		for (int i = 0; i < second.size(); i++)//считаем колиичество запятых во второй строке
		{
			if (second[i] == exam[0])
			{
				count++;
			}
		}
		if (count == 3)
		{
			count = 0;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0;
	}
	string nameFirst, timeFirst, amountFirst,cityFirst;//перемменые для разделения первой строки на 4 части
	int y = 0;
	for (int i = 0; i < first.size(); i++)
	{
		if (first[i] == exam[0])//поиск запятых
		{
			count++;
		switch (count)
		{
		case 1:
			nameFirst.insert(0, first,0,i);//вставка первой части
			y = i+1;

		case 2:
			timeFirst.insert(0, first, y, i-y);
			y = 0;
			y = i + 1;
		case 3:
			amountFirst.insert(0, first, y, i-y);
			count++;
			y = 0;
			y = i + 1;
		case 4:
			cityFirst.insert(0, first, y, i - y);
			y = 0;
			count = 0;

		default:
			break;
		}
		}	
	}
	string nameSecond, timeSecond, amountSecond,citySecond;//переменные для разделенния второй строки
	for (int i = 0; i < second.size(); i++)
	{
		if (second[i] == exam[0])
		{
			count++;
			switch (count)
			{
			case 1:
				nameSecond.insert(0, second, 0, i);
				y = i + 1;
			case 2:
				timeSecond.insert(0, second, y, i - y);
				y = 0;
				y = i + 1;
			case 3:
				amountSecond.insert(0, second, y, i - y);
				count++;
				y = 0;
				y = i + 1;
			case 4:
				citySecond.insert(0, second, y, i - y);
				y = 0;
			default:
				break;
			}
		}
	}
	if (nameFirst.size() > 10||nameFirst.size()<=1)//проверка выполнения условий (размер имени от 1 до 10)
	{
		return 0;
	}
	for (int i = 0; i < nameFirst.size(); i++)
	{
		if (isdigit(nameFirst[i]))//проверка на наличие чисел в имени
		{
			return 0;
		}
	}
	cout << "\n";

	int timeFirstString=fundnumbers(timeFirst);;//переменная для стека (время)(первая строка)	
	if (timeFirstString < 0 || timeFirstString>1000)//проверка на условие что время от 0 до 1000
	{
		return 0;
	}
	int amountFirstString=fundnumbers(amountFirst);//переменная суммы (первая строка)
	if (amountFirstString < 0 || amountFirstString>2000)//проверка условия что сумма от 0 до 20000
	{
		return 0;
	}
	if (cityFirst.size() > 10 || cityFirst.size() <= 1)//проверка что название города от 1 до 10
	{
		return 0;
	}
	for (int i = 0; i < cityFirst.size(); i++)//проверка на числа в названии города
	{
		if (isdigit(cityFirst[i]))
		{
			return 0;
		}
	}

	if (nameSecond.size() > 10 || nameSecond.size() <= 1)
	{
		return 0;
	}
	for (int i = 0; i < nameSecond.size(); i++)
	{
		if (isdigit(nameSecond[i]))
		{
			return 0;
		}
	}
	int timeSecondString=fundnumbers(timeSecond);
	
	if (timeSecondString < 0 || timeSecondString>1000)
	{
		return 0;
	}
	
	int amountSecondString=fundnumbers(amountSecond);
	if (amountSecondString < 0 || amountSecondString>2000)
	{
		return 0;
	}
	cout << "\n";
	if (citySecond.size() > 10 || citySecond.size() <= 1)
	{
		return 0;
	}
	for (int i = 0; i < citySecond.size(); i++)
	{
		if (isdigit(citySecond[i]))
		{
			return 0;
		}
	}
	if (amountFirstString > 1000)//выполнение условия что сумма не должна быть больше 1000 (транзикция не выполнится)(первая строка
	{
		for (int i = 0; i < first.size(); i++)
		{
			cout << first[i];
		}
	}
	cout << "\n";
	if (amountSecondString > 1000)//выполнение условия что сумма не должна быть больше 1000 (вторая строка)
	{
		for (int i = 0; i < second.size(); i++)
		{
			cout << second[i];
		}
	}
	cout << "\n";
	int count1 = 0;
	if (nameFirst.size() == nameSecond.size())//если имя первой строки и второй одинаковы по длине,возможно они одинаковы
	{
		for (int i = 0; i < nameFirst.size(); i++)
		{
			if (nameFirst[i] == nameSecond[i])
			{
				count1++;//счёт схожих букв в именах
			}
		}
	}
	for (int i = 0; i < cityFirst.size(); i++)
	{
		if (cityFirst[i] != citySecond[i]&&(timeFirstString-timeSecondString<=60||timeSecondString-timeFirstString<=60)&&count1==nameFirst.size()) //условие (города разные ,одинаковые имена,время меньше 60 минут) транзакция не ободренна
		{
			for (int u = 0; u < first.size(); u++)
			{
				cout << first[u]<<"\t";
			}
			for (int m = 0; m < second.size(); m++)
			{
				cout << second[m];
			}
		}
	}
	return 0;
}

