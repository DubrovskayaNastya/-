﻿#include <iostream>
#include <vector>
#include <string>
#include <stack>
#include <cmath>

using namespace std;

int calculate(string example)
{
	stack<int> operand;
	for (int i = 0; i < example.size(); i++) {
		if (isdigit(example[i])) {
			string num;
			while (i < example.size() && isdigit(example[i])) {
				num += example[i];
				i++;
			}
			i--;
			operand.push(stoi(num));
		}
	}
	return operand.empty() ? 0 : operand.top();
}

string result_numbers(int system_ascii, int number)
{
	string result;
	while (number > 0)
	{
		int digit = number % system_ascii;
		if (digit < 10)
		{
			result = static_cast<char>(digit + '0') + result;
		}
		else
		{
			result = static_cast<char>(digit - 10 + 'A') + result;
		}
		number /= system_ascii;
	}
	return result.empty() ? "0" : result;
}

int main()
{
	vector<string>input;
	cout << "Enter some string (If to stop Ctrl+Z) :\n";
	string text;
	while (getline(cin, text))
	{
		input.push_back(text);
	}
	vector<int>numbers;
	for (int i = 0; i < input.size(); i++)
	{
		string newtext = input[i];
		numbers.push_back(calculate(newtext));
	}
	cout << "You number is:\n";
	for (int i = 0; i < numbers.size(); i++)
	{
		cout << numbers[i] << "\n";
		if (numbers[0] < 1 || numbers[0]>100)
		{
			return 0;
		}
		if (numbers[i] < 1)
		{
			return 0;
		}
	}
	int system_ascii;
	cout << "System of calculate:\n"; 
	cin.clear(); 
	cin >> system_ascii;

	if (system_ascii < 2 || system_ascii > 36)
	{
		return 0;
	}
	vector<string>results;
	for (int i = 0; i < numbers.size(); i++)
	{
		results.push_back(result_numbers(system_ascii, numbers[i]));
	}
	cout << "You new numbers in system:\t" << system_ascii<<"\n";
	for (int i = 0 ; i < results.size(); i++)
	{
		cout << results[i] << "\n";
	}
	return 0;
}