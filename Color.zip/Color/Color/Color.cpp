﻿#include <iostream>
#include <vector>
using namespace std;

int main()
{
	srand(static_cast<unsigned>(time(NULL)));
	vector<int>color;
	int colors;
	for (int i = 0; i < 15; i++)
	{
		colors = rand() % 3;
		color.push_back(colors);
	}
	cout << "Color Array:\n";
	for (int i = 0; i < 15; i++)
	{
		cout << color[i] << "\t";
	}
	int colorRed = 0;
	int colorWhite = 0;
	int colorBlue = 0;
	vector<int>SortColor;
	for (int i = 0; i < 15; i++)
	{
		if (color[i] == 0)
		{
			colorRed++;
		}
		else if (color[i] == 1)
		{
			colorWhite++;
		}
		else if (color[i] == 2)
		{
			colorBlue++;
		}
	}
	for (int i = 0; i < colorRed; i++)
	{
		SortColor.push_back(0);
	}
	for (int i = 0; i < colorWhite; i++)
	{
		SortColor.push_back(1);
	}
	for (int i = 0; i < colorBlue; i++)
	{
		SortColor.push_back(2);
	}
	cout << "\nSort Color array:\n";
	for (int i = 0; i < SortColor.size(); i++)
	{
		cout << SortColor[i] << "\t";
	}
	if (colorRed > colorBlue &&colorRed>colorWhite)
	{
		system("Color C0");
	}
	else if (colorBlue > colorRed && colorBlue > colorWhite)
	{
		system("Color B0");
	}
	else if (colorWhite > colorRed && colorWhite > colorBlue)
	{
		system("Color F0");
	}
	return 0;
}